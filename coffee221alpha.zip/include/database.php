<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "coffee221";
$con = mysqli_connect($host, $user, $pass, $db);
?>